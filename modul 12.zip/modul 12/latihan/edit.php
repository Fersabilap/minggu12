<?php
include 'database.php';
$mysqli = new Databases();
?>
<form action="proses.php?aksi=update" method="post">
    <?php
    foreach ($mysqli->edit($_GET['id']) as $datas) :
    ?>
	
<head>
<link href="css/a.css" rel="stylesheet">
</head>
<center>
<br><br>
<h2>Silahkan ubah data </h2>
<br>
<br>
        <table class="input">
            <tr>
                <td>Nama</td>
                <input type="hidden" name="id" value="<?php echo $datas['id'] ?>"><td>
				<input type="text" name="nama" class="inputt" value="<?= $datas['nama']; ?>"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" name="alamat" class="inputt" value="<?= $datas['alamat']; ?>"></td>
            </tr>
		    <tr>
                <td>Logo</td>
                <td><input type="file" name="logo" id="exampleInputFile" class="inputt" value="<?= $datas['logo']; ?>"></td>
            </tr>     
         </table>
		  <td><input type="submit" value="Simpan" class="button"></td>
    <?php endforeach ?>
</form>